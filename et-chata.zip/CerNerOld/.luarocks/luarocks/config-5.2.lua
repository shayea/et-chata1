rocks_trees = {
   { name = [[system]], root = [[/home/cabox/workspace/CerNerOld/.luarocks]] }
}
